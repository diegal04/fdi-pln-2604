# === PLN BUTLER - MODELOS ===
#
# Modelos de datos Pydantic para el juego:
# - Carta: mensaje entre puestos
# - Inventario: recursos con operaciones aritméticas
# - InfoPuesto: estado de un puesto de juego

from typing import Any, Self

from pydantic import BaseModel, Field, GetCoreSchemaHandler
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import core_schema


class Carta(BaseModel):
    remi: str = Field("", description="Remitente (texto libre)")
    dest: str = Field("", description="Destinatario (texto libre)")
    asunto: str = Field("", description="Asunto del mensaje")
    cuerpo: str = Field("", description="Cuerpo del mensaje")
    id: str | None = Field(None, description="ID del mensaje, asignado por el servidor")
    fecha: str | None = Field(
        None, description="Fecha de entrega en formato ISO, asignado por el servidor"
    )


class Inventario(dict):
    """Diccionario de recursos (mapa recurso -> cantidad)."""

    def __missing__(self, key: str) -> int:
        return 0

    def __setitem__(self, key: str, value: int) -> None:
        if value < 0:
            raise ValueError(f"Inventario no puede ser negativo: {key}={value}")
        super().__setitem__(key, value)

    def __repr__(self) -> str:
        return "\n".join(f"{k}: {v}" for k, v in self.items() if v > 0)

    def __add__(self, otro: dict[str, int]) -> Self:
        nuevo = Inventario()
        for k in set(self.keys()) | set(otro.keys()):
            nuevo[k] = self[k] + otro.get(k, 0)
        return nuevo

    def __iadd__(self, otro: dict[str, int]) -> Self:
        """Operador += in-place"""
        for k, v in otro.items():
            self[k] += v
        return self

    def __sub__(self, otro: dict[str, int]) -> Self:
        """Operador -"""
        nuevo = Inventario()
        for k in set(self.keys()) | set(otro.keys()):
            nuevo[k] = self[k] - otro.get(k, 0)
        return nuevo

    def __isub__(self, otro: dict[str, int]) -> Self:
        """Operador -= in-place"""
        for k, v in otro.items():
            self[k] -= v
        return self

    @classmethod
    def _from_dict(cls, d: dict[str, int]) -> Self:
        inv = cls()
        for k, v in d.items():
            inv[k] = v  # Valida que no sea negativo
        return inv

    @classmethod
    def __get_pydantic_core_schema__(
        cls, source_type: Any, handler: GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        """Hook para que Pydantic sepa serializar/deserializar Inventario."""
        return core_schema.no_info_after_validator_function(
            lambda v: cls._from_dict(v) if not isinstance(v, cls) else v,
            core_schema.dict_schema(
                keys_schema=core_schema.str_schema(),
                values_schema=core_schema.int_schema(),
            ),
            serialization=core_schema.plain_serializer_function_ser_schema(dict),
        )

    @classmethod
    def __get_pydantic_json_schema__(
        cls, core_schema: core_schema.CoreSchema, handler: Any
    ) -> JsonSchemaValue:
        """Personaliza el schema JSON para mostrar ejemplo claro."""
        json_schema = handler(core_schema)
        json_schema["example"] = {"madera": 4, "oro": 2}
        return json_schema


class InfoPuesto(BaseModel):
    Alias: str = Field(
        default="",
        description="Nombre por el que puede recibir correo",
    )
    Buzon: dict[str, Carta] = Field(
        default_factory=dict, description="Mensajes recibidos, indexados por su id"
    )
    Recursos: Inventario = Field(
        default_factory=Inventario, description="Recursos disponibles"
    )
    Objetivo: Inventario = Field(
        default_factory=Inventario, description="Recursos objetivo"
    )
